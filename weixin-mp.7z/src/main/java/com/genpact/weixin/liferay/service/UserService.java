package com.genpact.weixin.liferay.service;

public class UserService {

}
