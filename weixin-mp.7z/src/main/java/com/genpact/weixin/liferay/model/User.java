package com.genpact.weixin.liferay.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import lombok.Data;

@Data
@Entity
@Table(name = "user_")
public class User {

	@Id
	@GeneratedValue(generator = "system-uuid")
	@GenericGenerator(name = "system-uuid", strategy = "uuid")
	String uuid_;
	Long userId;
	Long companyId;
	Date createDate;
	Date modifiedDate;
	Integer defaultUser;
	Long contactId;
	String password_;
	Integer passwordEncrypted;
	Integer passwordReset;
	Date passwordModifiedDate;
	String digest;
	String reminderQueryQuestion;
	String reminderQueryAnswer;
	Integer graceLoginCount;
	String screenName;
	String emailAddress;
	Long facebookId;
	Long ldapServerId;
	String openId;
	Long portraitId;
	String languageId;
	String timeZoneId;
	String greeting;
	String comments;
	String firstName;
	String middleName;
	String lastName;
	String jobTitle;
	Date loginDate;
	String loginIP;
	Date lastLoginDate;
	String lastLoginIP;
	Date lastFailedLoginDate;
	Integer failedLoginAttempts;
	Integer lockout;
	Date lockoutDate;
	Integer agreedToTermsOfUse;
	Integer emailAddressVerified;
	Integer status;

}
