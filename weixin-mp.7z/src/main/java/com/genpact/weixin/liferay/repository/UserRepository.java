package com.genpact.weixin.liferay.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.genpact.weixin.liferay.model.User;

@Repository
public interface UserRepository extends CrudRepository<User, String> {

	User findByOpenId(String openId);

	User findByScreenName(String screenName);

}