package com.genpact.weixin.mp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.genpact.weixin.liferay.model.User;
import com.genpact.weixin.liferay.repository.UserRepository;

import lombok.AllArgsConstructor;
import me.chanjar.weixin.mp.api.WxMpService;

@AllArgsConstructor
@Controller
@RequestMapping("/wx/bind")
public class BindLiferayController {
	private final WxMpService wxService;

	@Autowired
	private UserRepository userRepository;

	@GetMapping("/bindUser2Liferay")
	public String bindUser2Liferay(@RequestParam String openId, ModelMap map) {
		User user = new User();
		user.setOpenId(openId);
		map.put("user", user);
		return "bindUser2Liferay";
	}

	@PostMapping("/bindUser2Liferay")
	public String save(User user, ModelMap map) {
		User user2 = userRepository.findByOpenId(user.getOpenId());
		if (user2 != null) {
			user2.setOpenId("");
			userRepository.save(user2);
		} else {
			User user3 = userRepository.findByScreenName(user.getScreenName());
			user3.setOpenId(user.getOpenId());
			userRepository.save(user3);
		}

		return "bindUser2Liferay";
	}

}
