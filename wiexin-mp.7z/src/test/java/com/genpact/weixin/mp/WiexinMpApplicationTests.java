package com.genpact.weixin.mp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WiexinMpApplicationTests {

	@Test
	void contextLoads() {
	}

}
