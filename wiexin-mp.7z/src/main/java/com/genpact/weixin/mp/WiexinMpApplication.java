package com.genpact.weixin.mp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WiexinMpApplication {

	public static void main(String[] args) {
		SpringApplication.run(WiexinMpApplication.class, args);
	}

}
