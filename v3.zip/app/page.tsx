import React from "react";
import { Button } from "@/components/ui/button"; // 确保路径正确
import { Separator } from "@/components/ui/separator"; // 确保路径正确
import { Badge } from "@/components/ui/badge";
import {
  IconCircleCheckFilled,
  IconCircleArrowRight,
  IconCircleCaretRightFilled,
  IconCircleArrowRightFilled,
  IconSquareRoundedCheck,
  IconXboxX,
  IconCircleX,
  IconSquareLetterX,
  IconCircleHalfVertical,
} from "@tabler/icons-react";
import {
  Card,
  CardAction,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { AlertCircle, CircleCheck } from "lucide-react";
import { Step1 } from "@/components/step1";
import { Footer7 } from "@/components/footer7";
import Table1 from "@/components/table1";
import CardList1 from "@/components/card-list1";
import { Stats1 } from "@/components/stats1";

// 基础页面布局组件
export default function Home() {
  return (
    // Outer container: flex column, min height of screen to push footer down
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="border-b sticky top-0 z-40">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <a href="/" className="text-lg font-bold text-primary">
            Your Site
            {/* <img src="/g-logo.svg" alt="Logo" className="h-8 w-auto" /> */}
          </a>
          <nav className="flex items-center space-x-4">
            <a href="/about" className="text-sm font-medium hover:text-primary">
              About
            </a>
            <a
              href="/services"
              className="text-sm font-medium hover:text-primary"
            >
              Services
            </a>
            <a
              href="/contact"
              className="text-sm font-medium hover:text-primary"
            >
              Contact
            </a>
            {/* <Button variant="secondary" size="sm">
              Sign In
            </Button> */}
          </nav>
        </div>
      </header>

      {/* Main Content Area */}
      {/* flex-grow makes this section take up available space, pushing footer down */}
      <main className="flex-grow ">

        <section className="px-12 pb-12 pt-20">
          <div className="container mx-auto">
            <div className="flex px-24 gap-1 justify-between">
              <div className="w-4/12">
                <img
                  src="https://deifkwefumgah.cloudfront.net/shadcnblocks/block/placeholder-1.svg"
                  alt="placeholder hero"
                  className="max-h-[400px] w-full rounded-md object-cover lg:max-h-[400px]"
                />
              </div>
              <div className="w-7/12 flex flex-col items-start justify-center">
                <h1 className="text-4xl font-bold mb-4">
                  AI-Powered{" "}
                  <span className="gb-text rounded-xl px-4">
                    Value Creation
                  </span>
                </h1>
                <h1 className="text-3xl mb-6">For The Office Of The CFO</h1>
                <div className="grid grid-cols-2 grid-rows-2  w-full">
                  <div className="pr-4 pb-4">
                    <div className="flex flex-row border-2 rounded-full p-3">
                      <IconCircleCheckFilled
                        className="mr-3"
                        style={{ color: "green" }}
                      />
                      <span>
                        <b>10%</b> Reduction In DSO
                      </span>
                    </div>
                  </div>
                  <div className="pr-4 pb-4">
                    <div className="flex flex-row border-2 rounded-full p-3">
                      <IconCircleCheckFilled
                        className="mr-3"
                        style={{ color: "green" }}
                      />
                      <span>
                        <b>50%</b> Reduction In Idle Cash
                      </span>
                    </div>
                  </div>
                  <div className="pr-4 pb-4">
                    <div className="flex flex-row border-2 rounded-full p-3">
                      <IconCircleCheckFilled
                        className="mr-3"
                        style={{ color: "green" }}
                      />
                      <span>
                        <b>30%</b> Faster Financial Close
                      </span>
                    </div>
                  </div>
                  <div className="pr-4 pb-4">
                    <div className="flex flex-row border-2 rounded-full p-3">
                      <IconCircleCheckFilled
                        className="mr-3"
                        style={{ color: "green" }}
                      />
                      <span>
                        <b>40%</b> Increase In Productivity
                      </span>
                    </div>
                  </div>
                </div>

                <div className="pr-4 pb-4">
                  <div className="gb-secondary flex flex-row rounded-full p-3">
                    <span>See How AI Agents Work</span>
                    <IconCircleArrowRightFilled className="ml-3" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="px-12 pb-12">
          <div className="container mx-auto">
            <h1 className="text-5xl font-bold my-12 w-full text-center">
              180+ AI Agents Orchestrated On a Single Platform
            </h1>
            <CardList1></CardList1>
          </div>
        </section>

        <section className="px-12 pb-12">
          <div className="container mx-auto px-4">
            <h1 className="text-5xl font-bold my-12 w-full text-center">
              180+ AI Agents Orchestrated On a Single Platform
            </h1>
            <img
              src="https://deifkwefumgah.cloudfront.net/shadcnblocks/block/placeholder-1.svg"
              alt="placeholder"
              className="mb-8 mt-4 aspect-video w-full rounded-lg border object-cover max-h-[400px] "
            />
          </div>
        </section>

        <section className="px-12 pb-12">
          <div className="container mx-auto px-4">
            <h1 className="text-5xl font-bold my-12 w-full text-center">
              180+ AI Agents Orchestrated On a Single Platform
            </h1>
            
              <Table1></Table1>

          </div>
        </section>

        <section className="px-12 pb-12">
          <div className="container mx-auto px-4">
            {/* <h1 className="text-4xl font-bold mb-6 text-accent w-full text-center">
              180+ AI Agents Orchestrated On a Single Platform
            </h1> */}
            <h1 className="text-5xl font-bold my-12 w-full text-center">
              180+ AI Agents Orchestrated On a Single Platform
            </h1>
            <Step1></Step1>
          </div>
        </section>

        <section className="px-12 pb-12">
          <div className="container mx-auto px-4">
            <h1 className="text-5xl font-bold my-12 w-full text-center">
              180+ AI Agents Orchestrated On a Single Platform
            </h1>
            <Stats1></Stats1>
          </div>
        </section>

      </main>

      {/* Footer */}
      <footer className="border-t mt-12 py-8">
        <Footer7></Footer7>
      </footer>
    </div>
  );
}
