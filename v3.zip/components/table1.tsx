export default function Table1() {
  return (
    <div>
      <div className="flex w-full">
        <div className="flex flex-col w-8">
          <div className="h-8 mt-1"></div>
          <div className="flex-1 gb-text rounded-s-2xl flex items-center justify-center">
            <div className="transform -rotate-90 whitespace-nowrap">Hel1lo</div>
          </div>
        </div>
        <div className="flex flex-col flex-1 ml-1">
          <div className="h-8 flex items-center justify-center gb-text rounded-t-2xl">1</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1">2</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1">3</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1">4</div>
        </div>
        <div className="flex flex-col flex-1 ml-1">
          <div className="h-8 flex items-center justify-center gb-text rounded-t-2xl">1</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1">2</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1">4</div>
        </div>
        <div className="flex flex-col flex-1 ml-1">
          <div className="h-8 flex items-center justify-center gb-text rounded-t-2xl">1</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1">2</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1">3</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1">4</div>
        </div>
        <div className="flex flex-col flex-1 ml-1">
          <div className="h-8 flex items-center justify-center gb-text rounded-t-2xl">1</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1">2</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1">3</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1">4</div>
        </div>
        <div className="flex flex-col flex-1 ml-1">
          <div className="h-8 flex items-center justify-center gb-text rounded-t-2xl">1</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1">2</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1">4</div>
        </div>
        <div className="flex flex-col flex-1 ml-1">
          <div className="h-8 flex items-center justify-center gb-text rounded-t-2xl">1</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1">2</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1">3</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1">4</div>
        </div>
      </div>
      <div className="flex w-full">
        <div className="flex flex-col w-8">
          <div className="flex-1 gb-text rounded-s-2xl flex items-center justify-center mt-1">
            <div className="transform -rotate-90 whitespace-nowrap">Hel1lo</div>
          </div>
        </div>
        <div className="flex flex-col flex-1 ml-1">
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1">2</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1">4</div>
        </div>
        <div className="flex flex-col flex-1 ml-1">
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1">2</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1">3</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1">4</div>
        </div>
        <div className="flex flex-col flex-1 ml-1">
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1">2</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1">3</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1">4</div>
        </div>
        <div className="flex flex-col flex-1 ml-1">
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1">2</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1">4</div>
        </div>
        <div className="flex flex-col flex-1 ml-1">
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1">2</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1">3</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1">4</div>
        </div>
        <div className="flex flex-col flex-1 ml-1">
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1">2</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1">3</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1">4</div>
        </div>
      </div>

    </div>
  );
}
