import { IconAlertCircle, IconCircleCheck, IconCircleHalfVertical } from "@tabler/icons-react";
import { AlertCircle, CircleCheck } from "lucide-react";

export default function CardList1() {
  return (
    <div className="grid grid-cols-3 grid-rows-2 w-full">
      
      <div className="p-4">
        <div className="gb-card">
          <div className="gb-card-title text-lg font-semibold rounded-t-xl px-10 py-2">
            Card Title
          </div>
          <div className="gb-card-content rounded-b-xl p-4">
            <ul className="list-none">
              <li className="flex flex-row p-3">
                <IconCircleHalfVertical className="mx-3" />
                <span>Now this is a story all about how</span>
              </li>
              <li className="flex flex-row p-3">
                <IconCircleCheck className="mx-3" />
                <span>Now this is a story all about how</span>
              </li>
              <li className="flex flex-row p-3">
                <IconAlertCircle className="mx-3" />
                <span>Now this is a story all about how</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <div className="p-4">
        <div className="gb-card">
          <div className="gb-card-title text-lg font-semibold rounded-t-xl px-10 py-2">
            Card Title
          </div>
          <div className="gb-card-content rounded-b-xl p-4">
            <ul className="list-none">
              <li className="flex flex-row p-3">
                <IconCircleHalfVertical className="mx-3" />
                <span>Now this is a story all about how</span>
              </li>
              <li className="flex flex-row p-3">
                <IconCircleCheck className="mx-3" />
                <span>Now this is a story all about how</span>
              </li>
              <li className="flex flex-row p-3">
                <IconAlertCircle className="mx-3" />
                <span>Now this is a story all about how</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <div className="p-4">
        <div className="gb-card">
          <div className="gb-card-title text-lg font-semibold rounded-t-xl px-10 py-2">
            Card Title
          </div>
          <div className="gb-card-content rounded-b-xl p-4">
            <ul className="list-none">
              <li className="flex flex-row p-3">
                <IconCircleHalfVertical className="mx-3" />
                <span>Now this is a story all about how</span>
              </li>
              <li className="flex flex-row p-3">
                <IconCircleCheck className="mx-3" />
                <span>Now this is a story all about how</span>
              </li>
              <li className="flex flex-row p-3">
                <IconAlertCircle className="mx-3" />
                <span>Now this is a story all about how</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <div className="p-4">
        <div className="gb-card">
          <div className="gb-card-title text-lg font-semibold rounded-t-xl px-10 py-2">
            Card Title
          </div>
          <div className="gb-card-content rounded-b-xl p-4">
            <ul className="list-none">
              <li className="flex flex-row p-3">
                <IconCircleHalfVertical className="mx-3" />
                <span>Now this is a story all about how</span>
              </li>
              <li className="flex flex-row p-3">
                <IconCircleCheck className="mx-3" />
                <span>Now this is a story all about how</span>
              </li>
              <li className="flex flex-row p-3">
                <IconAlertCircle className="mx-3" />
                <span>Now this is a story all about how</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <div className="p-4">
        <div className="gb-card">
          <div className="gb-card-title text-lg font-semibold rounded-t-xl px-10 py-2">
            Card Title
          </div>
          <div className="gb-card-content rounded-b-xl p-4">
            <ul className="list-none">
              <li className="flex flex-row p-3">
                <IconCircleHalfVertical className="mx-3" />
                <span>Now this is a story all about how</span>
              </li>
              <li className="flex flex-row p-3">
                <IconCircleCheck className="mx-3" />
                <span>Now this is a story all about how</span>
              </li>
              <li className="flex flex-row p-3">
                <IconAlertCircle className="mx-3" />
                <span>Now this is a story all about how</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <div className="p-4">
        <div className="gb-card">
          <div className="gb-card-title text-lg font-semibold rounded-t-xl px-10 py-2">
            Card Title
          </div>
          <div className="gb-card-content rounded-b-xl p-4">
            <ul className="list-none">
              <li className="flex flex-row p-3">
                <IconCircleHalfVertical className="mx-3" />
                <span>Now this is a story all about how</span>
              </li>
              <li className="flex flex-row p-3">
                <IconCircleCheck className="mx-3" />
                <span>Now this is a story all about how</span>
              </li>
              <li className="flex flex-row p-3">
                <IconAlertCircle className="mx-3" />
                <span>Now this is a story all about how</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
      
    </div>
  );
}
