import { IconArrowRight } from "@tabler/icons-react";

interface Stats8Props {
  heading?: string;
  description?: string;
  link?: {
    text: string;
    url: string;
  };
  stats?: Array<{
    id: string;
    value: string;
    label: string;
  }>;
}

const Step1 = ({
  heading = "Platform performance insights",
  description = "Ensuring stability and scalability for all users",
  link = {
    text: "Read the full impact report",
    url: "https://www.shadcnblocks.com",
  },
  stats = [
    {
      id: "stat-1",
      value: "250%+",
      label: "average growth",
    },
    {
      id: "stat-2",
      value: "$2.5m",
      label: "annual savings per enterprise partner in user engagement",
    },
    {
      id: "stat-3",
      value: "200+",
      label: "integrations with top industry platforms",
    },
    {
      id: "stat-4",
      value: "99.9%",
      label: "customer satisfaction over the last year",
    },
  ],
}: Stats8Props) => {
  return (
    <div className="mt-14 grid gap-x-10 gap-y-8 md:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => (
        <div
          key={stat.id}
          className="flex flex-row gap-4 gb-box2 py-6 rounded-lg text-center content-between items-center"
        >
          <div className="flex-1 text-7xl font-bold">{stat.value}</div>
          <div className="w-14 flex-none gb-color-primary">
            <IconArrowRight></IconArrowRight>
          </div>
        </div>
      ))}
    </div>
  );
};

export { Step1 };
