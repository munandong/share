import { ArrowRight } from "lucide-react";

interface Stats8Props {
  heading?: string;
  description?: string;
  link?: {
    text: string;
    url: string;
  };
  stats?: Array<{
    id: string;
    value: string;
    label: string;
  }>;
}

const Stats1 = ({
  heading = "Platform performance insights",
  description = "Ensuring stability and scalability for all users",
  link = {
    text: "Read the full impact report",
    url: "https://www.shadcnblocks.com",
  },
  stats = [
    {
      id: "stat-1",
      value: "250%+",
      label: "average growth",
    },
    {
      id: "stat-2",
      value: "$2.5m",
      label: "annual savings per enterprise partner in user engagement",
    },
    {
      id: "stat-3",
      value: "200+",
      label: "integrations with top industry platforms",
    },
    {
      id: "stat-4",
      value: "99.9%",
      label: "customer satisfaction over the last year",
    },
  ],
}: Stats8Props) => {
  return (
    <section className="py-4">
      <div className="container">
        <div className="flex flex-col gap-4">
          <h2 className="text-2xl font-bold md:text-4xl">{heading}</h2>
          <p>{description}</p>
          <a
            href={link.url}
            className="flex items-center gap-1 font-bold hover:underline"
          >
            {link.text}
            <ArrowRight className="h-auto w-4" />
          </a>
        </div>
        <div className="mt-14 flex flex-row  flex-gap-8 justify-between items-center flex-wrap">
          {stats.map((stat) => (
            <div
              key={stat.id}
              className="flex flex-col gap-4 gb-box2 px-4 py-12 rounded-lg text-center h-60"
            >
              <div className="text-7xl font-bold">{stat.value}</div>
              <p className="text-accent max-w-80">{stat.label}</p>
              <p>hahah asd</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export { Stats1 };
