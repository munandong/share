export default function Table1() {
  return (
    <div className="text-center">
      <div className="flex w-full">
        <div className="flex flex-col w-8">
          <div className="h-8 mt-1"></div>
          <div className="flex-1 gb-text rounded-s-2xl flex items-center justify-center">
            <div className="transform -rotate-90 whitespace-nowrap">Local</div>
          </div>
        </div>
        <div className="flex flex-col flex-1 ml-1">
          <div className="h-8 flex items-center justify-center gb-text rounded-t-2xl">File Fetcher</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-4 px-6">Email Fetcher</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-4 px-6">RPA File Download Framework</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-4 px-6">SharePoint File Fetcher</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-4 px-6">Outlook Inflow Plug-In</div>
        </div>
        <div className="flex flex-col flex-1 ml-1">
          <div className="h-8 flex items-center justify-center gb-text rounded-t-2xl">Data Extraction</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-4 px-6">China VAT QR Solution</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-4 px-6">Agentic Capture Tool</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-4 px-6">UiPath GenAI Data Extractor</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-4 px-6">Smart Capture Tool(OCR Engine)</div>
        </div>
        <div className="flex flex-col flex-1 ml-1">
          <div className="h-8 flex items-center justify-center gb-text rounded-t-2xl">2/3 Way Match</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-4 px-6">2/3 Way Match Local API</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-4 px-6">2/3 Way Match Cloud API</div>
        </div>
        <div className="flex flex-col flex-1 ml-1">
          <div className="h-8 flex items-center justify-center gb-text rounded-t-2xl">ERP Posting</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-4 px-6">Ariba PO Posting RPA Framework</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-4 px-6">Cora PO Posting RPA Framework</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-4 px-6">SAP PO Posting RPA Framework</div>
        </div>
        <div className="flex flex-col flex-1 ml-1">
          <div className="h-8 flex items-center justify-center gb-text rounded-t-2xl">Data Storage</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-4 px-6">Shared Drive</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-4 px-6">SharePoint</div>
        </div>
        <div className="flex flex-col flex-1 ml-1">
          <div className="h-8 flex items-center justify-center gb-text rounded-t-2xl">AI Service Layer</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-4 px-6">Azure AI Services</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-4 px-6">Local LLM</div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-4 px-6">OCR Engine</div>
        </div>
      </div>
      <div className="flex w-full">
        <div className="flex flex-col w-8">
          <div className="flex-1 gb-text rounded-s-2xl flex items-center justify-center mt-1">
            <div className="transform -rotate-90 whitespace-nowrap">Cloud</div>
          </div>
        </div>
        <div className="flex flex-col flex-1 ml-1">
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-7 px-6"></div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-7 px-6"></div>
        </div>
        <div className="flex flex-col flex-1 ml-1">
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-7 px-6"></div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-7 px-6"></div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-7 px-6"></div>
        </div>
        <div className="flex flex-col flex-1 ml-1">
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-7 px-6"></div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-7 px-6"></div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-7 px-6"></div>
        </div>
        <div className="flex flex-col flex-1 ml-1">
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-7 px-6"></div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-7 px-6"></div>
        </div>
        <div className="flex flex-col flex-1 ml-1">
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-7 px-6"></div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-7 px-6"></div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-7 px-6"></div>
        </div>
        <div className="flex flex-col flex-1 ml-1">
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-7 px-6"></div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-7 px-6"></div>
          <div className="flex-1 flex items-center justify-center mt-1 gb-box1 py-7 px-6"></div>
        </div>
      </div>

    </div>
  );
}
