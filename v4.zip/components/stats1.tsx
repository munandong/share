import { ArrowRight } from "lucide-react";

interface Stats8Props {
  heading?: string;
  description?: string;
  link?: {
    text: string;
    url: string;
  };
  stats?: Array<{
    id: string;
    value: string;
    label: string;
    ftes: string;
  }>;
}

const Stats1 = ({
  heading = "AP Digital Transformation Progress",
  description = "Oct 2024 - Now",
  link = {
    text: "Read the full impact report",
    url: "https://www.shadcnblocks.com",
  },
  stats = [
    {
      id: "stat-1",
      value: "31%+",
      label: "159 FTEs",
      ftes: "PO",
    },
    {
      id: "stat-2",
      value: "$2.5m",
      label: "128 FTEs",
      ftes: "Non-PO",
    },
    {
      id: "stat-3",
      value: "200 /",
      label: "84 FTEs",
      ftes: "Payment",
    },
    {
      id: "stat-4",
      value: "60mn+",
      label: "67 FTEs",
      ftes: "AP Helpdesk",
    },
    {
      id: "stat-5",
      value: "99.9%",
      label: "73 FTEs",
      ftes: "AP Reporting / Accounting / VMD",
    },
  ],
}: Stats8Props) => {
  return (
    <section className="py-4">
      <div className="container">
        <div className="flex flex-col gap-4">
          <h2 className="text-2xl font-bold md:text-2xl">{heading}</h2>
          <p>{description}</p>
          {/* <a
            href={link.url}
            className="flex items-center gap-1 font-bold hover:underline"
          >
            {link.text}
            <ArrowRight className="h-auto w-4" />
          </a> */}
        </div>
        <div className="mt-14 flex flex-row  flex-gap-8 justify-between items-center flex-wrap">
          {stats.map((stat) => (
            <div
              key={stat.id}
              className="flex flex-col gap-4 gb-box2 px-4 py-12 rounded-lg text-center h-60"
            >
              <div className="text-7xl font-bold">{stat.value}</div>
              <div className="text-accent max-w-80">{stat.label}</div>
              <div>{stat.ftes}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export { Stats1 };
