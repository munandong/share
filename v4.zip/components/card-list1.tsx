import {
  IconAlertCircle,
  IconCircleCheck,
  IconCircleHalfVertical,
} from "@tabler/icons-react";
import { AlertCircle, CircleCheck } from "lucide-react";

export default function CardList1() {
  return (
    <>
      <div className="grid grid-cols-3 grid-rows-1 w-full">
        <div className="p-4">
          <div className="gb-card">
            <div className="gb-card-title text-lg font-semibold rounded-t-xl px-10 py-2">
              Inflow Management
            </div>
            <div className="gb-card-content rounded-b-xl p-4">
              <ul className="list-none">
                <li className="flex flex-row p-3">
                  <IconCircleCheck className="mx-3" />
                  <span>Email Fetcher(3 Version)</span>
                </li>
                <li className="flex flex-row p-3">
                  <IconCircleHalfVertical className="mx-3" />
                  <span>xxx System File Download Bot</span>
                </li>
                <li className="flex flex-row p-3">
                  <IconCircleCheck className="mx-3" />
                  <span>SharePoint File Fetcher</span>
                </li>
                <li className="flex flex-row p-3">
                  <IconCircleHalfVertical className="mx-3" />
                  <span>Outlook Inflow Plug-in</span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="p-4">
          <div className="gb-card">
            <div className="gb-card-title text-lg font-semibold rounded-t-xl px-10 py-2">
              Data Extraction
            </div>
            <div className="gb-card-content rounded-b-xl p-4">
              <ul className="list-none">
                <li className="flex flex-row p-3">
                  <IconCircleCheck className="mx-3" />
                  <span>China VAT QR Solution</span>
                </li>
                <li className="flex flex-row p-3">
                  <IconAlertCircle className="mx-3" />
                  <span>Agentic Capture Tool</span>
                </li>
                <li className="flex flex-row p-3">
                  <IconCircleHalfVertical className="mx-3" />
                  <span>UiPath GenAI Data Extraction</span>
                </li>
                <li className="flex flex-row p-3">
                  <IconAlertCircle className="mx-3" />
                  <span>EasySnip</span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="p-4">
          <div className="gb-card">
            <div className="gb-card-title text-lg font-semibold rounded-t-xl px-10 py-2">
              ERP / Workflow Uploading
            </div>
            <div className="gb-card-content rounded-b-xl p-4">
              <ul className="list-none">
                <li className="flex flex-row p-3">
                  <IconCircleHalfVertical className="mx-3" />
                  <span>Ariba PO Posting Automation</span>
                </li>
                <li className="flex flex-row p-3">
                  <IconCircleHalfVertical className="mx-3" />
                  <span>Cora PO Posting Automation</span>
                </li>
                <li className="flex flex-row p-3">
                  <IconCircleHalfVertical className="mx-3" />
                  <span>SAP PO Posting Automation</span>
                </li>
                <li className="flex flex-row p-3">
                  <span>&nbsp;</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div className="grid grid-cols-3 grid-rows-1 w-full">
        <div className="p-4">
          <div className="gb-card">
            <div className="gb-card-title text-lg font-semibold rounded-t-xl px-10 py-2">
              Data Validation
            </div>
            <div className="gb-card-content rounded-b-xl p-4">
              <ul className="list-none">
                <li className="flex flex-row p-3">
                  <IconAlertCircle className="mx-3" />
                  <span>Validation(QPA)</span>
                </li>
                <li className="flex flex-row p-3">
                  <IconAlertCircle className="mx-3" />
                  <span>Power Automate</span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="p-4">
          <div className="gb-card">
            <div className="gb-card-title text-lg font-semibold rounded-t-xl px-10 py-2">
              AP Case Tracking
            </div>
            <div className="gb-card-content rounded-b-xl p-4">
              <ul className="list-none">
                <li className="flex flex-row p-3">
                  <IconCircleHalfVertical className="mx-3" />
                  <span>QPA + SharePoint List</span>
                </li>
                <li className="flex flex-row p-3">
                  <IconCircleCheck className="mx-3" />
                  <span>QPA + Access</span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="p-4">
          <div className="gb-card">
            <div className="gb-card-title text-lg font-semibold rounded-t-xl px-10 py-2">
              2/3 Way Match
            </div>
            <div className="gb-card-content rounded-b-xl p-4">
              <ul className="list-none">
                <li className="flex flex-row p-3">
                  <IconCircleHalfVertical className="mx-3" />
                  <span>Smart Recon</span>
                </li>
                <li className="flex flex-row p-3">
                  <span>&nbsp;</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
