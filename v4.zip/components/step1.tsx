import { IconArrowRight } from "@tabler/icons-react";

interface Stats8Props {
  heading?: string;
  description?: string;
  link?: {
    text: string;
    url: string;
  };
  stats?: Array<{
    id: string;
    value: string;
    label: string;
  }>;
}

const Step1 = ({
  heading = "Platform performance insights",
  description = "Ensuring stability and scalability for all users",
  link = {
    text: "Read the full impact report",
    url: "https://www.shadcnblocks.com",
  },
  stats = [
    {
      id: "stat-1",
      value: "1. Process-Driven Module Selection",
      label: "Identify required steps and corresponding modules based on the workflow's business needs",
    },
    {
      id: "stat-2",
      value: "2. Adaptive Technology Stack Configuration",
      label: "Select the optimal implementation method(technology stack) for each module, aligned with the client's environmental constraints",
    },
    {
      id: "stat-3",
      value: "3. Custom Interface Development",
      label: "Design and develop interfaces to address Client-specific customization requirements",
    },
    {
      id: "stat-4",
      value: "4. Integrated Solution Deployment",
      label: "Combine all selected modules and interfaces into a cohesive final product, delivering a turnkey automation solution",
    },
  ],
}: Stats8Props) => {
  return (
    <div className="mt-14 grid gap-x-10 gap-y-8 md:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => (
        <div
          key={stat.id}
          className="flex flex-row gap-4 gb-box2 py-6 rounded-lg text-center content-between items-center"
        >
          <div className="flex-1 pl-4">
            <div className="gb-color-accent font-bold">{stat.value}</div>
            <div>{stat.label}</div>
          </div>
          <div className="w-14 flex-none gb-color-primary">
            <IconArrowRight></IconArrowRight>
          </div>
        </div>
      ))}
    </div>
  );
};

export { Step1 };
